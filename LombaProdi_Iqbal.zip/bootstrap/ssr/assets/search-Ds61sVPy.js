const _imports_0 = "/build/assets/search-Dkx3kuv0.svg";
export {
  _imports_0 as _
};
