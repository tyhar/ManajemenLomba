import { resolveComponent, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./InputError-fLcttu_2.js";
import { useForm } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "ForgotPassword",
  __ssrInlineRender: true,
  props: {
    status: {
      type: String
    }
  },
  setup(__props) {
    const form = useForm({
      email: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Button = resolveComponent("Button");
      _push(`<section${ssrRenderAttrs(mergeProps({ style: { "background": "url(../assets/images/login-images/bg-forgot-password.jpg)" } }, _attrs))}><div class="wrapper"><div class="section-authentication-signin d-flex justify-content-center my-5 my-lg-1"><div class="container-fluid jarak-top-lebih10"><div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3"><div class="col mx-auto" style="${ssrRenderStyle({ "padding-top": "70px" })}"><div class="card"><div class="card-body"><div class="border p-4 rounded"><div class="text-center"><img src="assets/images/icons/forgot-2.png" width="120"></div><h5 class="mt-5 font-weight-bold">Tidak ingat kata sandi?</h5><p class="text-lupa-pw">Masukkan Email anda yang terdaftar untuk mengatur ulang kata sandi</p><form><div class="my-4"><label class="email" value="Email">Email</label><input id="email" type="email" class="form-control form-control-lg"${ssrRenderAttr("value", unref(form).email)} required autofocus autocomplete="username" placeholder="Masukkan Email">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "mt-2",
        message: unref(form).errors.email
      }, null, _parent));
      _push(`</div><div class="d-grid gap-2">`);
      _push(ssrRenderComponent(_component_Button, {
        class: "btn btn-light btn-lg",
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Email Password Reset Link `);
          } else {
            return [
              createTextVNode(" Email Password Reset Link ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<a href="/login" class="btn btn-light btn-lg"><i class="bx bx-arrow-back me-1"></i>Kembali ke halaman login</a></div></form></div></div></div></div></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/ForgotPassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
