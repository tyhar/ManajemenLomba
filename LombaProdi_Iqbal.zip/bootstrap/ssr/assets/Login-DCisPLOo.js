import { reactive, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _imports_0 } from "./search-Ds61sVPy.js";
import "./Checkbox-CixedilU.js";
import { _ as _sfc_main$1 } from "./InputError-fLcttu_2.js";
import "./PrimaryButton-CZbnR4E4.js";
import { useForm, Link } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
$(document).ready(function() {
  $("#show_hide_password a").on("click", function(event) {
    event.preventDefault();
    if ($("#show_hide_password input").attr("type") == "text") {
      $("#show_hide_password input").attr("type", "password");
      $("#show_hide_password i").addClass("bx-hide");
      $("#show_hide_password i").removeClass("bx-show");
    } else if ($("#show_hide_password input").attr("type") == "password") {
      $("#show_hide_password input").attr("type", "text");
      $("#show_hide_password i").removeClass("bx-hide");
      $("#show_hide_password i").addClass("bx-show");
    }
  });
});
const _sfc_main = {
  __name: "Login",
  __ssrInlineRender: true,
  props: {
    //from backend
    canResetPassword: {
      type: Boolean
    },
    status: {
      type: String
    },
    //from frontend
    errors: Object
    // Corrected typo in prop name
  },
  setup(__props) {
    const captcha = reactive({
      question: "",
      answer: 0
      // tambahkan properti untuk menyimpan jawaban CAPTCHA
    });
    let captchaInput = "";
    function generateCaptcha() {
      const num1 = Math.floor(Math.random() * 10) + 1;
      const num2 = Math.floor(Math.random() * 10) + 1;
      captcha.question = `${num1} x ${num2}?`;
      captcha.answer = num1 * num2;
    }
    const form = useForm({
      email: "",
      password: "",
      remember: false
    });
    generateCaptcha();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ style: { "background": "url(../assets/images/login-images/bg-forgot-password.jpg)" } }, _attrs))}><div class="wrapper"><div class="section-authentication-signin d-flex justify-content-center my-5 my-lg-1"><div class="container-fluid jarak-top-lebih10"><div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3"><div class="col mx-auto" style="${ssrRenderStyle({ "padding-top": "90px" })}"><div class="card"><div class="card-body"><div class="border p-4 rounded"><div class="text-center"><h3>Login</h3><br></div><div class="form-body"><form class="row g-3"><div class="col-12"><label for="email" class="form-label">Email</label><input class="form-control" id="email" type="email"${ssrRenderAttr("value", unref(form).email)} required autofocus autocomplete="username" placeholder="Enter Email">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "mt-2",
        message: __props.errors.email
      }, null, _parent));
      _push(`</div><div class="col-12"><label for="password" class="form-label">Password</label><div class="input-group" id="show_hide_password"><input class="form-control border-end-0" id="password" type="password"${ssrRenderAttr("value", unref(form).password)} required placeholder="Enter Password" autocomplete="current-password">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "mt-2",
        message: __props.errors.password
      }, null, _parent));
      _push(`<a href="javascript:;" class="input-group-text bg-transparent"><i class="bx bx-hide"></i></a></div></div><div class="col-md-6 jarak-top-lebih4"></div><div class="col-md-6 text-end jarak-top-lebih7">`);
      if (__props.canResetPassword) {
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("password.request"),
          class: "underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Lupa Password? `);
            } else {
              return [
                createTextVNode(" Lupa Password? ")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="d-grid jarak-top-lebih10"><label style="${ssrRenderStyle({ "margin-right": "5px" })}">Hasil Dari</label><label for="captcha" class="form-label">${ssrInterpolate(captcha.question)}</label><div class="input-group"><input${ssrRenderAttr("value", unref(captchaInput))} type="text" class="form-control" id="captcha" placeholder="Enter Captcha"></div></div><div class="col-12"><div class="d-grid jarak-top-kurang5"><button class="btn btn-primary"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""}><i class="bx bx-user"></i> Log in </button></div><div class="login-separater text-center mb-4 jarak-top-kurang15"><span>ATAU MASUK DENGAN EMAIL</span><hr></div><div class="d-grid jarak-top-kurang4"><a class="btn shadow-sm btn-white" href="#"><span class="d-flex justify-content-center align-items-center"><img class="me-2"${ssrRenderAttr("src", _imports_0)} width="16" alt="Image Description"><span>Masuk dengan Google</span></span></a></div><div class="text-center jarak-top-kurang10"><br><p> Belum punya akun? <a${ssrRenderAttr("href", _ctx.route("register"))}>Daftar disini</a></p></div></div></form></div></div></div></div></div></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/Login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
