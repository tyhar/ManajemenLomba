import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}><header><div class="c-topbar"><nav class="navbar navbar-expand"><div class="navbar-tambah"><a href="/"><div class="navbar-left"><img src="/bootstrap/images/logo.png" alt="Logo"></div></a></div><div class="search-bar flex-grow-1"></div><div class="top-menu ms-auto"><ul class="navbar-nav align-items-center"><div class="user-info ps-3"><p class="user-name mb-0">Habib Shohiburrotib</p><p class="user-role">habib</p></div><div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i></div></ul></div></nav></div></header><div class="page-wrapper-new"><div class="page-content"><div class="card"><div class="card-body"><h4 class="mb-0">Tambah Event</h4><hr><div><div class="c-mb10"><label class="c-mb5-black"><b>Nama Event</b></label><input type="email" class="form-control" value="Olinas"></div><div class="c-mb10"><label class="c-mb5-black"><b>Judul</b></label><input type="email" class="form-control" value="OLINAS 2024"></div><div class="c-mb10"><label class="c-mb5-black"><b>Sub Judul</b></label><input type="email" class="form-control"></div><div class="c-mb10"><label class="c-mb5-black"><b>Judul Deskripsi</b></label><input type="email" class="form-control"></div><div><label class="c-mb5-black"><b>Deskripsi</b></label><div class="col-12"><textarea class="form-control c-mb10" id="inputProductDescription" rows="4">Olinas adalah</textarea></div></div><div><label class="form-label warna-hitam"><b>Tanggal Mulai</b></label><input type="date" class="form-control label-8"></div><div><label class="form-label warna-hitam"><b>Tanggal Berakhir</b></label><input type="date" class="form-control label-8"></div><div><label for="formFile" class="form-label warna-hitam"><b>Logo 1</b></label><input class="form-control" type="file" id="formFile"><p class="keterangan-foto">Max 2 MB ( 180 x 55 px )</p></div><div><label for="formFile" class="form-label warna-hitam jarak-top-lebih6"><b>Logo 2 (background)</b></label><input class="form-control" type="file" id="formFile"><p class="keterangan-foto">Max 2 MB ( 1200 x 800 px )</p></div><div><label for="formFile" class="form-label warna-hitam jarak-top-lebih6"><b>Logo 3</b></label><input class="form-control" type="file" id="formFile"><p class="keterangan-foto">Max 2 MB ( 450 x 450 px )</p></div></div><div class="btn-posisi"><button class="btn btn-primary button-tabel-right" onclick="window.location.href=&#39;/setting&#39;">Tambah</button><button class="btn btn-danger button-tabel-left" onclick="window.location.href=&#39;/setting&#39;">Batal</button></div></div></div></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Roles/Admin/Setting/Tambahsetting.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Tambahsetting = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Tambahsetting as default
};
