import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle } from "vue/server-renderer";
import "@inertiajs/vue3";
const _sfc_main = {
  __name: "Datatim",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String,
      required: true
    },
    username: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}><header><div class="c-topbar"><nav class="navbar navbar-expand"><div class="navbar-tambah"><div class="navbar-left"><a href="dashboard"><img src="/bootstrap/images/logo.png" alt="Logo"></a></div></div><div class="search-bar flex-grow-1"></div><div class="top-menu ms-auto"><ul class="navbar-nav align-items-center"><div class="user-info ps-3"><p class="user-name mb-0">${ssrInterpolate(_ctx.$page.props.userData.name)}</p><p class="user-role">${ssrInterpolate(_ctx.$page.props.userData.username)}</p></div><div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i></div></ul></div></nav></div></header><div class="page-wrapper-new"><div class="page-content"><div class="card"><div class="card-body"><h4 class="mb-0">INFO TIM LOMBA</h4><hr><div class="row"><div class="col-md-6 c-mb10"><label class="jarak-input"><b>Nama Tim</b></label><input type="email" class="form-control"></div><div class="col-md-6"><label class="jarak-input"><b>Instansi</b></label><input type="email" class="form-control"></div><div class="col-md-6"><label class="jarak-input"><b>Lomba</b></label><input type="email" class="form-control c-mb8"></div><div class="col-md-6"><label class="jarak-input"><b>No WhatsApp</b></label><input type="email" class="form-control c-mb8"></div><div class="col-md-6"><label class="jarak-input"><b>Email</b></label><input type="email" class="form-control"></div><div class="col-md-6"><label for="formFile" class="form-label jarak-teks11"><b>Surat</b></label><input class="form-control" type="file" id="formFile"></div><div class="col-md-6"><label for="formFile" class="form-label jarak-teks12"><b>Bukti Pembayaran</b></label><input class="form-control" type="file" id="formFile"></div></div><div style="${ssrRenderStyle({ "display": "flex" })}"><button class="btn btn-primary button-tabel-right" onclick="window.location.href=&#39;/daftarlomba&#39;">Simpan</button><button class="btn btn-danger button-tabel-left" onclick="window.location.href=&#39;/daftarlomba&#39;">Batal</button></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Roles/User/Daftar/Datatim.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
