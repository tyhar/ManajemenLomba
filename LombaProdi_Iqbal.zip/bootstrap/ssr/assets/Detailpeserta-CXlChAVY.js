import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs } from "vue/server-renderer";
import "@inertiajs/vue3";
const _sfc_main = {
  __name: "Detailpeserta",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}><header><div class="c-topbar"><nav class="navbar navbar-expand"><div class="navbar-tambah"><div class="navbar-left"><a href="dashboard"><img src="/bootstrap/images/logo.png" alt="Logo"></a></div></div><div class="search-bar flex-grow-1"></div><div class="top-menu ms-auto"><ul class="navbar-nav align-items-center"><div class="user-info ps-3"><p class="user-name mb-0">Habib Shohiburrotib</p><p class="user-role">habib</p></div><div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i></div></ul></div></nav></div></header><div class="page-wrapper-peserta"><div class="page-content"><div class="card container-hg180"><div class="card-body"><div class="row"><div class="col-md-7 label-left"><h5 class="judul-detail c-ml-80 c-mt10"><b>Tema Lomba</b></h5><div class="judul-lomba-index c-ml-80 warna-hitam"><b>Desain Website</b></div></div><div class="col-md-5 d-flex justify-content-end align-items-center"><a class="btn btn-primary crud-width-180 isi-data" href="/daftarlomba">Daftar Lomba</a></div></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Roles/User/Detailpeserta.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
