import { ssrRenderStyle } from "vue/server-renderer";
import "@inertiajs/vue3";
import { useSSRContext } from "vue";
const _sfc_main = {
  __name: "InformasiBerita",
  __ssrInlineRender: true,
  props: {
    canLogin: {
      type: Boolean
    },
    canRegister: {
      type: Boolean
    },
    laravelVersion: {
      type: String,
      required: true
    },
    phpVersion: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><nav class="navbar navbar-expand-lg main_menu"><div class="container"><a class="navbar-brand" href="#"><img src="/bootstrap/images/logo.png" alt="Olinas" class="img-fluid w-100"></a><button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><i class="far fa-bars menu_icon"></i><i class="far fa-times close_icon"></i></button><div class="collapse navbar-collapse" id="navbarNav"><ul class="navbar-nav ms-auto"><li class="nav-item"><a class="nav-link active" href="/#">Beranda</a></li><li class="nav-item"><a class="nav-link" href="/#tentang-section">Tentang</a></li><li class="nav-item"><a class="nav-link" href="/#lomba-section">Lomba</a></li><li class="nav-item"><a class="nav-link" href="/#timeline-section">Timeline</a></li><li class="nav-item"><a class="nav-link" href="/#berita-section">Berita</a></li><li class="nav-item"><a class="nav-link" href="/#sponsor-section">Sponsor</a></li><li class="nav-item"><a class="nav-link" href="/kontak">Kontak</a></li><li class="nav-item">`);
      if (!_ctx.$page.props.auth.user) {
        _push(`<div class="row"><div class="col"><a class="nav-link common_btn" href="/login">Login</a></div><div class="col"><a class="nav-link common_btn" href="/register">Register</a></div></div>`);
      } else {
        _push(`<a class="nav-link common_btn" href="/dashboard">Dashboard</a>`);
      }
      _push(`</li></ul></div></div></nav><br><br><section class="tf__event_details mt_195 xs_mt_100"><div class="container"><div class="row"><div class="col-12" style="${ssrRenderStyle({ "margin-top": "0px" })}"><h2 style="${ssrRenderStyle({ "text-align": "center", "margin-bottom": "50px" })}"><b>Ketua Emailkomp Periode 2024</b></h2><div class="tf__event_details_img"><img src="/bootstrap/images/farel.png" alt="event details" class="w-100"></div><div class="tf__event_details_text mt_35 wow fadeInUp" data-wow-duration="1.5s"><ul class="location d-flex flex-wrap" style="${ssrRenderStyle({ "margin-top": "50px" })}"><li><i class="fas fa-user"></i> Admin</li><li><i class="far fa-clock"></i> 12-12-2023</li></ul><p>Emailkomp adalah sebuah organisasi dibawah pengawa langsung oleh D3 Teknik Informatika. </p></div></div></div></div></section><footer class="tf__footer mt_100"><div class="text-center p-4" style="${ssrRenderStyle({ "background-color": "#191e24f5", "color": "white" })}"> Copyright ©2024 Tim Website OLINAS </div></footer><div class="tf__scroll_btn" href="#"> go to top </div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Utama/InformasiBerita.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
