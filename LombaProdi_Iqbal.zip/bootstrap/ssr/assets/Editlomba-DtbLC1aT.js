import { mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrIncludeBooleanAttr, ssrLooseContain } from "vue/server-renderer";
import { usePage, useForm } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Editlomba",
  __ssrInlineRender: true,
  props: ["name", "username", "kriterias"],
  setup(__props) {
    const { name, username, kriterias } = __props;
    console.log(name);
    console.log(username);
    const lomba = usePage().props.lombas;
    const form = useForm({
      name_lomba: lomba.data.name_lomba,
      pj: lomba.data.pj,
      description: lomba.data.description,
      kontak: lomba.data.kontak,
      tempat: lomba.data.tempat,
      biaya_pendaftaran: lomba.data.biaya_pendaftaran,
      picture: lomba.data.picture ? `/storage/${lomba.data.picture}` : null,
      sertifikat: lomba.data.sertifikat ? `/storage/${lomba.data.sertifikat}` : null,
      selectedCriteria: []
      // New criteria will be added here
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}><header><div class="c-topbar"><nav class="navbar navbar-expand"><div class="navbar-tambah"><div class="navbar-left"><img src="/bootstrap/images/logo.png" alt="Logo"></div></div><div class="search-bar flex-grow-1"></div><div class="top-menu ms-auto"><ul class="navbar-nav align-items-center"><div class="user-info ps-3"><p class="user-name mb-0">${ssrInterpolate(_ctx.$page.props.userData.name)}</p><p class="user-role">${ssrInterpolate(_ctx.$page.props.userData.username)}</p></div><div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i></div></ul></div></nav></div></header><div class="page-wrapper-new"><div class="page-content"><div class="card"><form enctype="multipart/form-data"><div class="card-body"><h4 class="mb-0">Edit Lomba</h4><hr><div class="row"><div class="col-md-6 c-mb10"><label class="c-mb5-black"><b>Nama Lomba</b></label><input type="text" class="form-control"${ssrRenderAttr("value", unref(form).name_lomba)} id="name"></div><div class="col-md-6 c-mb10"><label class="c-mb5-black"><b>Nama PJ</b></label><input type="text" class="form-control"${ssrRenderAttr("value", unref(form).pj)} id="pj"></div><div class="col-md-6"><label class="c-mb5-black"><b>Deskripsi</b></label><div class="col-12"><textarea type="text" class="form-control" id="description">${ssrInterpolate(unref(form).description)}</textarea></div><div><label for="picture" class="form-label judul-form"><b>Gambar</b></label><input type="file" id="picture" accept="image/*" class="form-control"><p class="keterangan-foto">Ukuran 500 x 500</p></div><div><label for="sertifikat" class="form-label judul-form"><b>Sertifikat</b></label><input type="file" id="sertifikat" accept="image/*" class="form-control"></div></div><div class="col-md-6"><label class="c-mb5-black"><b>Kontak PJ</b></label><input type="number" class="form-control"${ssrRenderAttr("value", unref(form).kontak)} id="kontak"><div><label class="c-mb5-black"><b>Tempat</b></label><input type="text" class="form-control"${ssrRenderAttr("value", unref(form).tempat)} id="tempat"></div><div class="c-mt10"><label class="c-mb5-black"><b>Biaya Pendaftaran</b></label><input type="text" class="form-control"${ssrRenderAttr("value", unref(form).biaya_pendaftaran)} id="biaya_pendaftaran"></div><div><label class="role-add"><b class="warna-hitam">Kriteria Lomba</b></label><div><!--[-->`);
      ssrRenderList(__props.kriterias.data, (kriteria) => {
        _push(`<div class="form-check"><input class="form-check-input" type="checkbox"${ssrRenderAttr("id", "kriteria" + kriteria.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).selectedCriteria) ? ssrLooseContain(unref(form).selectedCriteria, kriteria.id) : unref(form).selectedCriteria) ? " checked" : ""}${ssrRenderAttr("value", kriteria.id)}><label class="form-check-label"${ssrRenderAttr("for", "kriteria" + kriteria.id)}>${ssrInterpolate(kriteria.name_kriteria)}</label></div>`);
      });
      _push(`<!--]--></div></div></div></div><div class="btn-posisi"><button type="submit" class="btn btn-primary button-tabel-right"> Update </button><button class="btn btn-danger btn-kembali">Kembali</button></div></div></form></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Roles/Admin/Lomba/Editlomba.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
