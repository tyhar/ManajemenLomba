import { mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Tambahkriteria",
  __ssrInlineRender: true,
  props: ["name", "username"],
  setup(__props) {
    const { name, username } = __props;
    console.log(name);
    console.log(username);
    const form = useForm({
      kriteria: [{ name_kriteria: "" }]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}><header><div class="c-topbar"><nav class="navbar navbar-expand"><div class="navbar-tambah"><div class="navbar-left"><a href="/"><img src="/bootstrap/images/logo.png" alt="Logo"></a></div></div><div class="search-bar flex-grow-1"></div><div class="top-menu ms-auto"><ul class="navbar-nav align-items-center"><div class="user-info ps-3"><p class="user-name mb-0">${ssrInterpolate(_ctx.$page.props.userData.name)}</p><p class="user-role">${ssrInterpolate(_ctx.$page.props.userData.username)}</p></div><div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i></div></ul></div></nav></div></header><div class="page-wrapper-new"><div class="page-content"><div class="card"><div class="card-body"><h4 class="mb-0">Tambah Kriteria Lomba</h4><hr><form enctype="multipart/form-data"><!--[-->`);
      ssrRenderList(unref(form).kriteria, (criteria, index) => {
        _push(`<div class="row"><div class="c-mt10"><label class="c-mb5-black c-mt10"><b>Kriteria Penilaian</b></label><div><input type="text" class="form-control label-8"${ssrRenderAttr("value", criteria.name_kriteria)}>`);
        if (unref(form).kriteria.length > 1) {
          _push(`<button class="btn btn-secondary"><i class="fas fa-minus"></i></button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></div>`);
      });
      _push(`<!--]--><button class="btn btn-secondary"><i class="fas fa-plus"></i> Tambah Kriteria</button><div class="btn-posisi"><button type="submit" class="btn btn-primary button-tabel-right">Tambah</button><button class="btn btn-danger btn-kembali">Batal</button></div></form></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Roles/Admin/Kriteria/Tambahkriteria.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
