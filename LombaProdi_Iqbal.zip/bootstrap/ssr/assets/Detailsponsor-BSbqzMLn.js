import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrRenderStyle } from "vue/server-renderer";
import "@inertiajs/vue3";
const _sfc_main = {
  __name: "Detailsponsor",
  __ssrInlineRender: true,
  props: ["name", "username", "sponsors"],
  setup(__props) {
    const { name, username, sponsors } = __props;
    console.log(name);
    console.log(username);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}><header><div class="c-topbar"><nav class="navbar navbar-expand"><div class="navbar-tambah"><a href="/"><div class="navbar-left"><img src="/bootstrap/images/logo.png" alt="Logo"></div></a></div><div class="search-bar flex-grow-1"></div><div class="top-menu ms-auto"><ul class="navbar-nav align-items-center"><div class="user-info ps-3"><p class="user-name mb-0">${ssrInterpolate(_ctx.$page.props.userData.name)}</p><p class="user-role">${ssrInterpolate(_ctx.$page.props.userData.username)}</p></div><div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i></div></ul></div></nav></div></header><div class="page-wrapper-new"><div class="page-content"><div class="card"><div class="card-body"><h4 class="mb-0">Detail Berita</h4><hr><div><div class="col-md-6 c-mb10"><label class="c-mb5-black"><b>Nama Sponsor</b></label><div class="c-mb20">${ssrInterpolate(__props.sponsors.name)}</div></div><div><label class="col-md-6 c-mb10 warna-hitam"><b>Link</b></label><div class="c-mb20"><a href="#">${ssrInterpolate(__props.sponsors.link_file)}</a></div></div><div class="c-mb10"><label class="c-mb5-black"><b>Gambar</b></label><br><div><img${ssrRenderAttr("src", "/storage/" + __props.sponsors.logo)} alt="Product Image" class="img-fluid" style="${ssrRenderStyle({ "display": "flex", "margin": "auto" })}"></div></div></div><div class="btn-posisi"><a class="btn btn-danger btn-kembali"${ssrRenderAttr("href", _ctx.route("sponsor.index"))}>Kembali</a><a class="btn btn-danger btn-kembali"${ssrRenderAttr("href", _ctx.route("sponsor.edit", __props.sponsors.id))}>Edit</a></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Roles/Admin/Sponsor/Detailsponsor.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
