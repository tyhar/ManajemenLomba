import { mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Tambahsponsor",
  __ssrInlineRender: true,
  props: ["name", "username"],
  setup(__props) {
    const { name, username } = __props;
    console.log(name);
    console.log(username);
    const form = useForm({
      name: "",
      logo: null,
      link_file: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}><header><div class="c-topbar"><nav class="navbar navbar-expand"><div class="navbar-tambah"><a href="/"><div class="navbar-left"><img src="/bootstrap/images/logo.png" alt="Logo"></div></a></div><div class="search-bar flex-grow-1"></div><div class="top-menu ms-auto"><ul class="navbar-nav align-items-center"><div class="user-info ps-3"><p class="user-name mb-0">${ssrInterpolate(_ctx.$page.props.userData.name)}</p><p class="user-role">${ssrInterpolate(_ctx.$page.props.userData.username)}</p></div><div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i></div></ul></div></nav></div></header><div class="page-wrapper-new"><div class="page-content"><div class="card"><form><div class="card-body"><h4 class="mb-0">Tambah Sponsor</h4><hr><div><div class="c-mb10"><label for="name" class="c-mb5-black"><b>Nama Sponsor</b></label><input type="text" class="form-control"${ssrRenderAttr("value", unref(form).name)} id="name"></div><div><label for="link_file" class="c-mb5-black"><b>Link</b></label><div class="col-12"><input type="text"${ssrRenderAttr("value", unref(form).link_file)} id="link_file" class="form-control c-mb10" rows="2"></div></div><div><label for="logo" class="form-label warna-hitam"><b>Logo</b></label><input class="form-control" type="file" id="logo"><p class="keterangan-foto">Max 2 MB (500 x 500 px)</p></div></div><div class="btn-posisi"><button type="submit" class="btn btn-primary button-tabel-right"> Tambah </button><a class="btn btn-danger button-tabel-left"${ssrRenderAttr("href", _ctx.route("sponsor.index"))}> Batal </a></div></div></form></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Roles/Admin/Sponsor/Tambahsponsor.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
