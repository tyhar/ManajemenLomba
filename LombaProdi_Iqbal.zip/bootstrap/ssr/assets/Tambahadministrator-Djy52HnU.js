import { mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList } from "vue/server-renderer";
import { useForm } from "@inertiajs/vue3";
$(document).ready(function() {
  $("#show_hide_password a").on("click", function(event) {
    event.preventDefault();
    const inputPassword = $("#password");
    const icon = $("#show_hide_password i");
    if (inputPassword.attr("type") === "text") {
      inputPassword.attr("type", "password");
      icon.removeClass("bx-show").addClass("bx-hide");
    } else if (inputPassword.attr("type") === "password") {
      inputPassword.attr("type", "text");
      icon.removeClass("bx-hide").addClass("bx-show");
    }
  });
});
const _sfc_main = {
  __name: "Tambahadministrator",
  __ssrInlineRender: true,
  props: ["name", "username", "lombas"],
  setup(__props) {
    const { name, username, lombas } = __props;
    console.log(name);
    console.log(username);
    const form = useForm({
      name: null,
      username: null,
      email: null,
      password: null,
      role: null,
      selectedLomba: []
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "wrapper" }, _attrs))}><header><div class="c-topbar"><nav class="navbar navbar-expand"><div class="navbar-tambah"><div class="navbar-left"><a href="/"><img src="/bootstrap/images/logo.png" alt="Logo"></a></div></div><div class="search-bar flex-grow-1"></div><div class="top-menu ms-auto"><ul class="navbar-nav align-items-center"><div class="user-info ps-3"><p class="user-name mb-0">${ssrInterpolate(_ctx.$page.props.userData.name)}</p><p class="user-role">${ssrInterpolate(_ctx.$page.props.userData.username)}</p></div><div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i></div></ul></div></nav></div></header><div class="page-wrapper-new"><div class="page-content"><div class="card"><div class="card-body"><h4 class="mb-0">TAMBAH ADMINISTRATOR</h4><hr><form><div class="row"><div class="col-md-6 margin-top10-crud"><label class="c-mb5-black"><b>Nama Lengkap</b></label><input id="name" type="name" class="form-control"${ssrRenderAttr("value", unref(form).name)}></div><div class="col-md-6 margin-top10-crud"><label class="c-mb5-black"><b>Username</b></label><input id="username" type="username" class="form-control"${ssrRenderAttr("value", unref(form).username)}></div><div class="col-md-12 margin-top10-crud"><label class="c-mb5-black"><b>Email</b></label><input id="email" type="email" class="form-control"${ssrRenderAttr("value", unref(form).email)}></div><div><label for="inputChoosePassword" class="form-label warna-hitam"><b>Password</b></label><div class="input-group" id="show_hide_password"><input type="password" class="form-control border-end-0" id="password"${ssrRenderAttr("value", unref(form).password)}><a href="javascript:;" class="input-group-text bg-transparent"><i class="bx bx-hide"></i></a></div></div><div><label class="role-add"><b class="warna-hitam">Role</b></label><select class="form-select" id="role"><option selected disabled>Pilih Role</option><option${ssrRenderAttr("value", 1)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).role) ? ssrLooseContain(unref(form).role, 1) : ssrLooseEqual(unref(form).role, 1)) ? " selected" : ""}>Admin</option><option${ssrRenderAttr("value", 4)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).role) ? ssrLooseContain(unref(form).role, 4) : ssrLooseEqual(unref(form).role, 4)) ? " selected" : ""}>Juri</option><option${ssrRenderAttr("value", 2)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).role) ? ssrLooseContain(unref(form).role, 2) : ssrLooseEqual(unref(form).role, 2)) ? " selected" : ""}>Petugas</option></select></div><div><label class="role-add"><b class="warna-hitam">Lomba</b></label><div><!--[-->`);
      ssrRenderList(__props.lombas.data, (lomba) => {
        _push(`<div class="form-check"><input class="form-check-input" type="checkbox"${ssrRenderAttr("id", "lomba" + lomba.id)}${ssrIncludeBooleanAttr(Array.isArray(unref(form).selectedLomba) ? ssrLooseContain(unref(form).selectedLomba, lomba.id) : unref(form).selectedLomba) ? " checked" : ""}${ssrRenderAttr("value", lomba.id)}><label class="form-check-label"${ssrRenderAttr("for", "lomba" + lomba.id)}>${ssrInterpolate(lomba.name_lomba)}</label></div>`);
      });
      _push(`<!--]--></div></div><div class="btn-posisi"><button class="btn btn-primary button-tabel-right" type="submit"> Tambah </button><a class="btn btn-danger button-tabel-left"${ssrRenderAttr("href", _ctx.route("administrator.index"))}> Batal </a></div></div></form></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Roles/Admin/Administrator/Tambahadministrator.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
