<script setup>
import { Link } from '@inertiajs/vue3';
</script>
<template>
    <div class="wrapper">
        <!--start header -->
        <header>
            <div class="c-topbar">
                <nav class="navbar navbar-expand">
                    <!-- Navbar tambah untuk logo di kiri -->
                    <div class="navbar-tambah">
                        <div class="navbar-left">
                            <a href="dashboard">
                                <img src="/bootstrap/images/logo.png" alt="Logo">
                            </a>
                        </div>
                    </div>
                    <!-- Mobile toggle menu -->
                    <!-- Search bar -->
                    <div class="search-bar flex-grow-1">
                    </div>
                    <!-- Top menu -->
                    <div class="top-menu ms-auto">
                        <ul class="navbar-nav align-items-center">
                            <div class="user-info ps-3">
                                <p class="user-name mb-0">Habib Shohiburrotib</p>			
                                <p class="user-role">habib</p>					
                            </div>
                            <div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i>
                            </div>
                        </ul>
                    </div>		
                </nav>
            </div>
        </header>
        <!--end header -->
        <!--start page wrapper -->
        <div class="page-wrapper-peserta">
            <div class="page-content">
                <div class="card container-hg180">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-7 label-left">
                                <h5 class="judul-detail c-ml-80 c-mt10"><b>Tema Lomba</b></h5>
                                <div class="judul-lomba-index c-ml-80 warna-hitam"><b>Desain Website</b></div>
                            </div>
                            <div class="col-md-5 d-flex justify-content-end align-items-center">
                                <a class="btn btn-primary crud-width-180  isi-data" href="/daftarlomba">Daftar Lomba</a>
                            </div>
                        </div>
                    </div>      
                </div>
            </div>
        </div>
        <!--end page wrapper -->
    </div>

</template>
    