<script setup>
import { useForm, Link, router } from "@inertiajs/vue3";
import { reactive } from "vue";


const { name, username, lombas } = defineProps(['name', 'username', 'lombas']);

console.log(name); // Contoh penggunaan di dalam script setup
console.log(username);

const props = {
    lombas: {
        type: Array,
    },
};

const form = useForm({
    name: null,
    username: null,
    email: null,
    password: null,
    role: null,
    selectedLomba: [],
});

function submit() {
  // Menambahkan properti selectedCriteria ke dalam data yang disubmit
  const formData = { ...form, selectedLomba: form.selectedLomba };
  router.post('/administrator', formData);
}



// const form = reactive({
//   name: null,
//   email: null,
//   password: null,
//   role: null, // Tambahkan role di sini
// })


// function submit() {
//     router.post(route("administrator.store"), form)
// }

</script>
<template>
    <div class="wrapper">
        <!--start header -->
        <header>
            <div class="c-topbar">
                <nav class="navbar navbar-expand">
                    <!-- Navbar tambah untuk logo di kiri -->
                    <div class="navbar-tambah">
                        <div class="navbar-left">
                            <a href="/">
                                <img src="/bootstrap/images/logo.png" alt="Logo">
                            </a>
                        </div>
                    </div>
                    <!-- Mobile toggle menu -->
                    <!-- Search bar -->
                    <div class="search-bar flex-grow-1">
                    </div>
                    <!-- Top menu -->
                    <div class="top-menu ms-auto">
                        <ul class="navbar-nav align-items-center">
                            <div class="user-info ps-3">
                                <p class="user-name mb-0">{{ $page.props.userData.name }}</p>
                                <p class="user-role">{{ $page.props.userData.username }}</p>
                            </div>
                            <div class="parent-icon posisi-icon"><i class="bx bx-user-circle c-font48"></i>
                            </div>
                        </ul>
                    </div>
                </nav>
            </div>
        </header>
        <!--end header -->
        <!--start page wrapper -->
        <div class="page-wrapper-new">
            <div class="page-content">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mb-0">TAMBAH ADMINISTRATOR</h4>
                        <hr />
                        <form @submit.prevent="submit">
                            <div class="row">
                                <div class="col-md-6 margin-top10-crud">
                                    <label class="c-mb5-black"><b>Nama Lengkap</b></label>
                                    <input
                                        id="name" 
                                        type="name" 
                                        class="form-control"
                                        v-model="form.name"
                                    >
                                </div>

                                <div class="col-md-6 margin-top10-crud">
                                    <label class="c-mb5-black"><b>Username</b></label>
                                    <input
                                        id="username"
                                        type="username" 
                                        class="form-control"
                                        v-model="form.username"
                                    >
                                </div>
                                <div class="col-md-12 margin-top10-crud">
                                    <label class="c-mb5-black"><b>Email</b></label>
                                    <input
                                        id="email" 
                                        type="email" 
                                        class="form-control"
                                        v-model="form.email"
                                    >
                                </div>
                                <div>
                                    <label for="inputChoosePassword"
                                        class="form-label warna-hitam"><b>Password</b></label>
                                    <div class="input-group" id="show_hide_password">
                                        <input 
                                            type="password" 
                                            class="form-control border-end-0"
                                            id="password"
                                            v-model="form.password"
                                        > 
                                            <a href="javascript:;" class="input-group-text bg-transparent">
                                                <i class='bx bx-hide'></i>
                                            </a>
                                    </div>
                                </div>
                                <div>
                                    <label class="role-add "><b class="warna-hitam">Role</b></label>
                                    <select 
                                        class="form-select" 
                                        id="role" 
                                        v-model="form.role"
                                    >
                                        <option selected disabled>Pilih Role</option>
                                        <option :value="1">Admin</option>
                                        <option :value="4">Juri</option>
                                        <option :value="2">Petugas</option>
                                    </select>
                                </div>
                                <div>
                               <label class="role-add"><b class="warna-hitam">Lomba</b></label>
                              <div>   
                         <div class="form-check" v-for="lomba in lombas.data" :key="lomba.id">
                       <input class="form-check-input" type="checkbox" :id="'lomba' + lomba.id" v-model="form.selectedLomba" :value="lomba.id">
                       <label class="form-check-label" :for="'lomba' + lomba.id">{{ lomba.name_lomba }}</label>
                       </div>
                         </div>
                               </div>                                   
                                <div class="btn-posisi">
                                    <button 
                                        class="btn btn-primary button-tabel-right"
                                        type="submit"
                                    >
                                        Tambah
                                    </button>
                                    <a 
                                        class="btn btn-danger button-tabel-left"
                                        :href="route('administrator.index')"
                                    >
                                        Batal
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!--end page wrapper -->
    </div>
    </template>
<script>
$(document).ready(function () {
    $("#show_hide_password a").on('click', function (event) {
        event.preventDefault();
        const inputPassword = $('#password');
        const icon = $('#show_hide_password i');
        if (inputPassword.attr("type") === "text") {
            inputPassword.attr('type', 'password');
            icon.removeClass("bx-show").addClass("bx-hide");
        } else if (inputPassword.attr("type") === "password") {
            inputPassword.attr('type', 'text');
            icon.removeClass("bx-hide").addClass("bx-show");
        }
    });
});
</script>
