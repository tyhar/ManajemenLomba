<template>
    <!--=================================
        ERROR PAGE START
    ==================================-->
    <section class="tf__error_page mt_195 xs_mt_100">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 m-auto wow fadeInUp" data-wow-duration="1.5s">
                    <div class="tf__error_text">
                        <div class="img">
                            <img src="../../../public/bootstrap/images/error_img.png" alt="error" class="img-fluid w-100">
                        </div>
                        <h4>Page not found</h4>
                        <p>SABAR YAKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK</p>
                        <a class="common_btn" href="/index2">go to home</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=================================
        ERROR PAGE END
    ==================================-->
    
    <!--=================================
           FOOTER START
       ==================================-->
       <footer class="tf__footer mt_100">
            <div class="text-center p-4" style="background-color: #191e24f5; color: white;">
                Copyright ©2024 Tim Website OLINAS
            </div>
        </footer>
       <!--=================================
           FOOTER END
       ==================================-->

</template>