<script setup>
import { Head, Link } from '@inertiajs/vue3';

defineProps({
    canLogin: {
        type: Boolean,
    },
    canRegister: {
        type: Boolean,
    },
    laravelVersion: {
        type: String,
        required: true,
    }, 
    phpVersion: {
        type: String,
        required: true,
    },
});

function handleImageError() {
    document.getElementById('screenshot-container')?.classList.add('!hidden');
    document.getElementById('docs-card')?.classList.add('!row-span-1');
    document.getElementById('docs-card-content')?.classList.add('!flex-row');
    document.getElementById('background')?.classList.add('!hidden');
}
</script>

<template>
    <!--=================================
       MAIN MENU START
    ==================================-->
   <nav class="navbar navbar-expand-lg main_menu">
       <div class="container">
           <a class="navbar-brand" href="#">
               <img src="/bootstrap/images/logo.png" alt="Olinas" class="img-fluid w-100">
           </a>
           <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
               aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
               <i class="far fa-bars menu_icon"></i>
               <i class="far fa-times close_icon"></i>
           </button>
           <div class="collapse navbar-collapse" id="navbarNav">
               <ul class="navbar-nav ms-auto">
                   <li class="nav-item">
                       <a class="nav-link active" href="/#">Beranda</a>
                   </li>
                   <li class="nav-item">
                       <a class="nav-link" href="/#tentang-section">Tentang</a>
                   </li>
                   <li class="nav-item">
                       <a class="nav-link" href="/#lomba-section">Lomba</a>
                   </li>
                   <li class="nav-item">
                       <a class="nav-link" href="/#timeline-section">Timeline</a>
                   </li>
                   <li class="nav-item">
                       <a class="nav-link" href="/#berita-section">Berita</a>
                   </li>
                   <li class="nav-item">
                       <a class="nav-link" href="/#sponsor-section">Sponsor</a>
                   </li>
                   <li class="nav-item">
                       <a class="nav-link" href="/kontak">Kontak</a>
                   </li>
                   <li class="nav-item">
                        <template v-if="!$page.props.auth.user">
                            <div class="row">
                            <div class="col">
                                <a class="nav-link common_btn" href="/login">Login</a>
                            </div>
                            <div class="col">
                                <a class="nav-link common_btn" href="/register">Register</a>
                            </div>
                            </div>
                        </template>
                        <template v-else>
                            <a class="nav-link common_btn" href="/dashboard">Dashboard</a>
                        </template>
                    </li>
               </ul>
           </div>
       </div>
   </nav>
   <!--=================================
       MAIN MENU END
   ==================================-->

    <br><br>
   <!--=================================
       BANNER START
   ==================================-->
   <section class="tf__event_details mt_195 xs_mt_100">
        <div class="container">
            <div class="row">
                <div class="col-12" style="margin-top: 0px;">
                    <h2 style="text-align: center; margin-bottom: 50px;"><b>Ketua Emailkomp Periode 2024</b> </h2>
                    <div class="tf__event_details_img "> 
                        <img src="/bootstrap/images/farel.png" alt="event details" class="w-100">
                    </div>
                    <div class="tf__event_details_text mt_35 wow fadeInUp" data-wow-duration="1.5s">
                        <ul class="location d-flex flex-wrap"  style="margin-top: 50px;">
                            <li><i class="fas fa-user"></i> Admin</li>
                            <li><i class="far fa-clock"></i> 12-12-2023</li>
                        </ul>
                        <p>Emailkomp adalah sebuah organisasi dibawah pengawa langsung oleh D3 Teknik Informatika. </p>
                    </div>
                </div>
            </div>
        </div>
    </section>


   <!--=================================
       FOOTER START
   ==================================-->
    <footer class="tf__footer mt_100">
        <div class="text-center p-4" style="background-color: #191e24f5; color: white;">
            Copyright ©2024 Tim Website OLINAS
        </div>
   </footer>
   <!--=================================
       FOOTER END
   ==================================-->


   <!--=============================
       SCROLL BUTTON START
   ==============================-->
   <div class="tf__scroll_btn" href="#"> go to top </div>
   <!--=============================
       SCROLL BUTTON END 
   ==============================-->
</template>

