<?php echo e($slot); ?>

<?php /**PATH D:\PROJECT SAYA\LombaProdi_Iqbal\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>